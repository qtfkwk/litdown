#include <stdio.h>

int main ()
{
	puts ("Hello!");
}
